# Ruteprofiler

- `cycling-regular` – almindelig cykel
- `cycling-electric` – elcykel
- `cycling-road` – landevejscykel
- `cycling-mountain` – mountainbike
- `foot-walking` – gåtur

Vores Camping v19 bruger elcykelprofilen til ruteberegning og til start-/slutrækkevidde i fem minutters intervaller.
