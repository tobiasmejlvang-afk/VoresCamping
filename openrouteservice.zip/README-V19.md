# Openrouteservice-udvidelser – Vores Camping v19

Denne mappe samler de vedhæftede svar-eksempler og de API-funktioner, som er kodet ind i `docs/ors.js`.

## Implementeret i appen

- Geocode search
- Geocode autocomplete
- Struktureret geokodning
- Reverse geokodning
- Directions via POST og GET
- Cykelprofiler, inkl. `cycling-electric`
- Snap til vejnet i GeoJSON og JSON
- Isokroner og elcykel-rækkevidde
- Afstands- og tidsmatrix
- POI-søgning
- Højdedata for punkt og linje
- Optimering via VROOM

API-nøglen gemmes kun lokalt i browseren og udelades fra backupfiler.
